package com.example.demo.controller;

import com.example.demo.exception.AppException;
import com.example.demo.model.Department;
import com.example.demo.model.Role;
import com.example.demo.model.User;
import com.example.demo.payload.ApiResponse;
import com.example.demo.payload.ChangePassword;
import com.example.demo.payload.Employee;
import com.example.demo.payload.JwtAuthenticationResponse;
import com.example.demo.payload.LoginRequest;
import com.example.demo.payload.SignUpRequest;
import com.example.demo.repository.DepartmentRepository;
import com.example.demo.repository.RoleRepository;
import com.example.demo.repository.UserRepository;
import com.example.demo.security.JwtTokenProvider;
import com.example.demo.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;
import javax.validation.Valid;
import java.net.URI;
import java.util.Collections;
import org.apache.commons.lang3.RandomStringUtils;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    @Autowired
    AuthenticationManager authenticationManager;

    @Autowired
    UserRepository userRepository;

    @Autowired
    RoleRepository roleRepository;

    @Autowired
    DepartmentRepository departmentRepository;

    @Autowired
    PasswordEncoder passwordEncoder;

    @Autowired
    JwtTokenProvider tokenProvider;

    @Autowired
    private UserService userService;

    @Autowired
    private JavaMailSender javaMailSender;
    
    @PostMapping("/signin")
    public ResponseEntity<?> authenticateUser(@Valid @RequestBody LoginRequest loginRequest) {

        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(loginRequest.getUsernameOrEmail(), loginRequest.getPassword()));

        SecurityContextHolder.getContext().setAuthentication(authentication);

        String jwt = tokenProvider.generateToken(authentication);
        return ResponseEntity.ok(new JwtAuthenticationResponse(jwt));
    }

    @PostMapping("/signup")
    public ResponseEntity<?> registerUser(@Valid @RequestBody SignUpRequest signUpRequest) {
        try{
            if (userRepository.existsByEmail(signUpRequest.getEmail())) {
                return new ResponseEntity(new ApiResponse(false, "Email Address already in use!"), HttpStatus.BAD_REQUEST);
            }

            String password = passwordEncoder.encode("employee");

            Long d_id = new Long(signUpRequest.getDepartment());
            Department department = departmentRepository.getOne(d_id);

            User employee = new User(signUpRequest.getUserId(), signUpRequest.getEmail(), signUpRequest.getFirstName(), 
                                     signUpRequest.getSecondName(), signUpRequest.getInitials(), signUpRequest.getGender(), 
                                     signUpRequest.getEmail(), signUpRequest.getResidence(), signUpRequest.getContact(), 
                                     department, signUpRequest.getDesignation(), signUpRequest.getSupervisor1(), signUpRequest.getSupervisor2(), signUpRequest.getJoinDate(), 
                                     signUpRequest.getConfirmDate(), "Not resign", password, "Working", signUpRequest.getAnnual(), 
                                     signUpRequest.getCasual(), signUpRequest.getMedical());

            Role userRole = roleRepository.findById(signUpRequest.getRole())
                    .orElseThrow(() -> new AppException("User Role not set."));

            employee.setRoles(Collections.singleton(userRole));

            User result = userRepository.save(employee);

            URI location = ServletUriComponentsBuilder.fromCurrentContextPath().path("/users/{username}")
                    .buildAndExpand(result.getEmail()).toUri();

            return ResponseEntity.created(location).body(new ApiResponse(true, "User registered successfully!"));
        }catch(Exception e){
            return ResponseEntity.ok(new ApiResponse(false, "User registered unsuccessfully!"));
        }
    }

    @PostMapping("/forgot")
    public ResponseEntity<?> forgotPassword(@RequestBody LoginRequest request){

        User user = userRepository.findByUsername(request.getUsernameOrEmail());
        
        String confirmCode =RandomStringUtils.randomAlphabetic(4);

        try {

            if (!userRepository.existsByEmail(request.getUsernameOrEmail())) {
                return new ResponseEntity(new ApiResponse(false, "Username incorrect!"), HttpStatus.BAD_REQUEST);
            }

            SimpleMailMessage msg = new SimpleMailMessage();
            msg.setTo(request.getUsernameOrEmail());
            msg.setSubject("Forgot credentials of VX Leave.");
            msg.setText("Hi "+user.getFirstName()+" "+user.getSecondName()+",\n\n"+
					"You forgot your credentials and waiting for confirm code.\n"+
					"Your requested confirm code is "+ confirmCode + ".\n\n"+
					"Thanks. \nBest Regards"
                    );
                     
            javaMailSender.send(msg);
            user.setConfirmCode(confirmCode);
            userRepository.save(user);
            return ResponseEntity.ok(new ApiResponse(true, "Check email for confirm code"));
		}catch (Exception e){
            return new ResponseEntity(new ApiResponse(false, "Fail, Send again!"), HttpStatus.BAD_REQUEST);
		}
    }

    @PostMapping("/forgot_password")
    public Boolean changeForgotPassword(@RequestBody ChangePassword passwords){

        User user = userRepository.findByUsername(passwords.getEmail());
        String code = user.getConfirmCode();

        if(passwords.getCurrentPassword().equals(code)){
            String password = passwordEncoder.encode(passwords.getNewPassword());
            user.setPassword(password);
            user.setConfirmCode(null);
            userRepository.save(user);
            return true;
        }else{
            return false;
        }
        
    }

    @GetMapping("/info")
    public Employee getInfo(@RequestHeader("Authorization") String token) {
        if(StringUtils.hasText(token) && token.startsWith("Bearer ")){
            String jwt = token.substring(7);
            Long id = tokenProvider.getUserIdFromJWT(jwt);

            return userService.searchById(id);
        }
        return null;
    }

    @PostMapping("/change_password")
    public Boolean getOldPassword(@RequestHeader("Authorization") String token, @RequestBody ChangePassword passwords) {
        
        String jwt = token.substring(7);
        Long id = tokenProvider.getUserIdFromJWT(jwt);
        
        User user = userRepository.getOne(id);
        String username = user.getUsername();

        try{
            Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(username, passwords.getCurrentPassword()));

            String password = passwordEncoder.encode(passwords.getNewPassword());
            user.setPassword(password);
            userRepository.save(user);
            return true;
        }catch(Exception e){
            return false;
        }
    }

    @GetMapping("/correct")
    public Boolean checkValidity(@RequestHeader("Authorization") String token) {        
        
        return true;
    }        
}