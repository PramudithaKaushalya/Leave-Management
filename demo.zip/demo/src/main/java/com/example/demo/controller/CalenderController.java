package com.example.demo.controller;

import java.util.List;
import com.example.demo.model.Calender;
import com.example.demo.model.User;
import com.example.demo.payload.CalenderRecord;
import com.example.demo.repository.UserRepository;
import com.example.demo.security.JwtTokenProvider;
import com.example.demo.service.CalenderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(value = "/calender")
public class CalenderController {

    @Autowired
    private  CalenderService calenderService;
    
    @Autowired
    JwtTokenProvider tokenProvider;

    @Autowired
    UserRepository userRepository;

    @GetMapping("/all")
    public List<CalenderRecord> getAll() {
        return calenderService.getAll();
    }

    @PostMapping("/set_date")
    public Boolean setDate(@RequestHeader("Authorization") String token, @RequestBody Calender calender){

        String jwt = token.substring(7);
        Long id = tokenProvider.getUserIdFromJWT(jwt);
        
        User user = userRepository.getOne(id);

        return calenderService.saveDate(calender, user);
    }

    @GetMapping("/delete/{id}")
    public String deleteById(@PathVariable("id") Long id) {
        return calenderService.deleteDate(id);
    }

    @GetMapping("/dates")
    public List<String> getDates() {
        return calenderService.getDates();
    }
}