package com.example.demo.controller;

import java.util.List;

import com.example.demo.payload.LeaveCountDTO;
import com.example.demo.payload.LeaveProfileDTO;
import com.example.demo.service.LeaveCountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(value = "/leave_count")
public class LeaveCountController {

    @Autowired
    private LeaveCountService leaveCountService;

    @GetMapping("/profile")
    public List<LeaveProfileDTO> getProfile() {
        return leaveCountService.getProfile();
    }

    @GetMapping("/profile/{id}")
    public LeaveProfileDTO getOneProfile(@PathVariable("id") Long id) {
        return leaveCountService.getOneProfile(id);
    }

    @GetMapping("/summery/{id}")
    public List<LeaveCountDTO> getSummery(@PathVariable("id") Long id) {
        return leaveCountService.summery(id);
    }
}