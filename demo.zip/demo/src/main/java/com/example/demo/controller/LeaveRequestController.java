package com.example.demo.controller;

import java.util.List;
import com.example.demo.model.LeaveRequest;
import com.example.demo.model.User;
import com.example.demo.payload.LeaveRecord;
import com.example.demo.security.JwtTokenProvider;
import com.example.demo.service.LeaveRequestService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

// @CrossOrigin(origins = "*")
@RestController
@RequestMapping(value = "/leave")
public class LeaveRequestController {

    @Autowired
    private LeaveRequestService leaveRequestService;

    @Autowired
    JwtTokenProvider tokenProvider;
    
    @GetMapping("/all")
    public List<LeaveRecord> getAll() {
        return leaveRequestService.getAll();
    }

    @GetMapping("/find/{id}")
    public List<LeaveRequest> getOneEmployeeLeaveRequests(@PathVariable("id") User employee) {
        return leaveRequestService.getOneEmployeeLeaveRequests(employee);
    }

    @PostMapping(value = "/request")
    public String addEmployee(@RequestBody LeaveRequest leaveRequest) {
        return leaveRequestService.addRequest(leaveRequest);
    }

    @GetMapping("/pending")
    public List<LeaveRecord> getPending() {
        String pending = "Pending";
        return leaveRequestService.getPending(pending);
    }

    @GetMapping("/delete/{id}")
    public String DeleteById(@PathVariable("id") LeaveRequest request) {
        Integer id = request.getLeave_id();
        return leaveRequestService.deleteLeave(id);
    }

    @GetMapping("/approve/{id}")
    public String ApproveById(@RequestHeader("Authorization") String token, @PathVariable("id") LeaveRequest request) {

        String jwt = token.substring(7);
        Long id = tokenProvider.getUserIdFromJWT(jwt);

        return leaveRequestService.approveRequest(id, request);
    }

    @PostMapping(value = "/reject/{id}")
    public String updateUser( @RequestHeader("Authorization") String token, @RequestBody LeaveRequest reason, @PathVariable("id") Integer id) {
        
        String jwt = token.substring(7);
        Long check_id = tokenProvider.getUserIdFromJWT(jwt);

        return leaveRequestService.rejectRequest(id, reason, check_id);
    }

    @GetMapping("/absent")
    public List<LeaveRequest> getAbsence() {
        return leaveRequestService.getAbsence();
    }
}