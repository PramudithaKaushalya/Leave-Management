package com.example.demo.controller;

import java.util.List;
import com.example.demo.model.LeaveType;
import com.example.demo.model.User;
import com.example.demo.repository.UserRepository;
import com.example.demo.security.JwtTokenProvider;
import com.example.demo.service.LeaveTypeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(value = "/leave_type")
public class LeaveTypeController {

    @Autowired
    private LeaveTypeService leaveTypeService;

    @Autowired
    JwtTokenProvider tokenProvider;

    @Autowired
    UserRepository userRepository;
    
    @GetMapping("/all")
    public List<LeaveType> getAll(@RequestHeader("Authorization") String token) {
        if(StringUtils.hasText(token) && token.startsWith("Bearer ")){
            String jwt = token.substring(7);
            Long id = tokenProvider.getUserIdFromJWT(jwt);

            User user = userRepository.getOne(id);
            Long role_id = user.getRoles().stream().findFirst().get().getId();

            if(role_id == 1L || role_id == 2L || role_id == 6L){
                return leaveTypeService.getAll();
            }else{
                
                System.out.println("||||||||||||||||||||||"+leaveTypeService.getSome().get(0).getType());
                return leaveTypeService.getSome();
            }
        }
        return null;
    }
}