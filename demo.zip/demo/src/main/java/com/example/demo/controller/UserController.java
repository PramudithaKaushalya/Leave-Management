package com.example.demo.controller;

import java.util.List;
import javax.validation.Valid;
import com.example.demo.payload.*;
import com.example.demo.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.security.core.Authentication;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import com.example.demo.security.JwtTokenProvider;

@RestController
@RequestMapping("/user")
public class UserController {

    @Autowired
    private UserService userService;

    @Autowired
    AuthenticationManager authenticationManager;

    @Autowired
    JwtTokenProvider tokenProvider;

    @GetMapping("/all")
    public List<Employee> getAll() {
        return userService.getAll();
    }

    @GetMapping("/get/{id}")
    public Employee getOne(@PathVariable("id") Long id) {
        return userService.searchById(id);
    }

    @PostMapping(value = "/resign")
    public String resignUser(@RequestBody  Employee employee) {

        return userService.resignEmployee(employee);
    }

    @PostMapping(value = "/update/{id}")
    public String updateUser(@RequestBody UpdateUser employee, @PathVariable("id") Long id) {
        return userService.updateEmployee(id, employee);
    }

    @GetMapping("/supervisor")
    public List<Supervisor> findSupervisors() {
        return userService.searchSupervisors();
    }

    @PostMapping("/signin")
    public Authentication authenticateUser(@Valid @RequestBody LoginRequest loginRequest) {

        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(loginRequest.getUsernameOrEmail(), loginRequest.getPassword()));

        return authentication;
    }
}
