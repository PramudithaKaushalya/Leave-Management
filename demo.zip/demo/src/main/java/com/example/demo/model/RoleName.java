package com.example.demo.model;

public enum  RoleName {
    Supervisor,
    Permanent,
    Probation,
    Intern,
    Contract,
    Admin
}
