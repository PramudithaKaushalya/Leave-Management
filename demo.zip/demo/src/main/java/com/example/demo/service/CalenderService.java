package com.example.demo.service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import com.example.demo.model.Calender;
import com.example.demo.model.User;
import com.example.demo.payload.CalenderRecord;
import com.example.demo.repository.CalenderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CalenderService {

    @Autowired
    private CalenderRepository calenderRepository;

    public Boolean saveDate(Calender date, User user) {
        
        LocalDateTime datetime1 = LocalDateTime.now();  
        DateTimeFormatter format = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");  
        String createdAt = datetime1.format(format);

        date.setCreatedAt(createdAt);
        date.setCreatedBy(user);

        try{
            calenderRepository.save(date);
            return true;
        }catch(Exception e){
            return false;
        }
    }

    public List<CalenderRecord> getAll() {

        List<Calender> all = calenderRepository.findAll();
        List<CalenderRecord> records = new ArrayList<CalenderRecord>();
        
        for (Calender var : all) {
            CalenderRecord record = new CalenderRecord(var.getId(), var.getDate(), var.getReason(), var.getCreatedBy().getFirstName()+var.getCreatedBy().getSecondName(), var.getCreatedAt());
            records.add(record);            
        }
        return records;
    }

    public String deleteDate(Long id) {
        calenderRepository.deleteById(id);
        return "Remove Holiday successfull";
    }

    public List<String> getDates() {
        List<String> dates = new ArrayList<String>();

        List<Calender> all = calenderRepository.findAll();
        
        for (Calender var : all) {
            dates.add(var.getDate());            
        }
        return dates;
    }
}