package com.example.demo.service;

import java.util.List;
import com.example.demo.model.Contact;
import com.example.demo.model.User;
import com.example.demo.repository.ContactRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ContactService {

    @Autowired
    private ContactRepository contactRepository;

    public List<Contact> getOne(User user) {
        return contactRepository.findByUser(user);
    }

    public String addContact(Contact contact) {
        contactRepository.save(contact);
        return "Contact added successfull!";
    }

    public String deleteContact(Integer id) {
        contactRepository.deleteById(id);
        return "Contact deleted!";
    }
}