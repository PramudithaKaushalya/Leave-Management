package com.example.demo.service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import com.example.demo.model.LeaveCount;
import com.example.demo.model.LeaveRequest;
import com.example.demo.model.LeaveType;
import com.example.demo.model.User;
import com.example.demo.payload.LeaveRecord;
import com.example.demo.repository.LeaveCountRepository;
import com.example.demo.repository.LeaveRequestRepository;
import com.example.demo.repository.UserRepository;
import org.slf4j.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

@Service
public class LeaveRequestService {

    @Autowired
    private LeaveRequestRepository leaveRequestRepository;

    @Autowired
    private LeaveCountRepository leaveCountRepository;

    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private JavaMailSender javaMailSender;
    
	private static final Logger LOGGER = LoggerFactory.getLogger(LeaveRequestService.class);

    public List<LeaveRecord> getAll() {
        List<LeaveRequest> all = leaveRequestRepository.findAll();
        List<LeaveRecord> requests = new ArrayList<LeaveRecord>();

        for (LeaveRequest request : all) {
            if(request.getStatus().equals("Pending") && request.getDuty()==null){
                LeaveRecord record = new LeaveRecord( request.getLeave_id(), request.getLeave_type().getType(), request.getUser().getId(), request.getUser().getFirstName()+" "+request.getUser().getSecondName(), request.getUser().getDepartment().getName(), request.getStart_date(), 
                                                      request.getEnd_date(), request.getStartHalf(), request.getEndHalf(), request.getNumber_of_leave_days(), request.getUser().getSupervisor1(), request.getUser().getSupervisor2(), 
                                                      "No one assigned", request.getSpecial_notes(), request.getStatus(), request.getReject(), request.getFormatDateTime(), "Not Checked", "Not Checked" );
                requests.add(record);
            }else if(!request.getStatus().equals("Pending") && request.getDuty()==null){
                LeaveRecord record = new LeaveRecord( request.getLeave_id(), request.getLeave_type().getType(), request.getUser().getId(), request.getUser().getFirstName()+" "+request.getUser().getSecondName(), request.getUser().getDepartment().getName(), request.getStart_date(), 
                                                      request.getEnd_date(), request.getStartHalf(), request.getEndHalf(), request.getNumber_of_leave_days(), request.getUser().getSupervisor1(), request.getUser().getSupervisor2(), 
                                                      "No one assigned", request.getSpecial_notes(), request.getStatus(), request.getReject(), request.getFormatDateTime(), request.getCheckBy().getFirstName()+" "+request.getCheckBy().getSecondName(), request.getCheckTime() );
                requests.add(record);
            }else if(request.getStatus().equals("Pending") && request.getDuty()!=null){
                LeaveRecord record = new LeaveRecord( request.getLeave_id(), request.getLeave_type().getType(), request.getUser().getId(), request.getUser().getFirstName()+" "+request.getUser().getSecondName(), request.getUser().getDepartment().getName(), request.getStart_date(), 
                                                      request.getEnd_date(), request.getStartHalf(), request.getEndHalf(), request.getNumber_of_leave_days(), request.getUser().getSupervisor1(), request.getUser().getSupervisor2(), 
                                                      request.getDuty().getFirstName()+" "+request.getDuty().getSecondName(), request.getSpecial_notes(), request.getStatus(), request.getReject(), request.getFormatDateTime(), "Not Checked", "Not Checked" );
                requests.add(record);
            }else{
                LeaveRecord record = new LeaveRecord( request.getLeave_id(), request.getLeave_type().getType(), request.getUser().getId(), request.getUser().getFirstName()+" "+request.getUser().getSecondName(), request.getUser().getDepartment().getName(), request.getStart_date(), 
                                                  request.getEnd_date(), request.getStartHalf(), request.getEndHalf(), request.getNumber_of_leave_days(), request.getUser().getSupervisor1(), request.getUser().getSupervisor2(), request.getDuty().getFirstName()+" "+request.getDuty().getSecondName(),
                                                  request.getSpecial_notes(), request.getStatus(), request.getReject(), request.getFormatDateTime() , request.getCheckBy().getFirstName()+" "+request.getCheckBy().getSecondName(), request.getCheckTime() );
                requests.add(record);
            }                                      
        }
        return requests;
    }

    public List<LeaveRequest> getOneEmployeeLeaveRequests(User employee) {
        return leaveRequestRepository.findByUser(employee);
    }

    public String addRequest(LeaveRequest leaveRequest) {
        LocalDateTime datetime1 = LocalDateTime.now();  
        DateTimeFormatter format = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");  
        String formatDateTime = datetime1.format(format);
        leaveRequest.setFormatDateTime(formatDateTime);

        leaveRequestRepository.save(leaveRequest);
        return "Submited your request!!!";
    }

    public List<LeaveRecord> getPending(String pending) {
        List<LeaveRequest> pendingLeaves = leaveRequestRepository.findByStatus(pending);
        List<LeaveRecord> requests = new ArrayList<LeaveRecord>();

        for (LeaveRequest request : pendingLeaves) {
            if(request.getDuty()==null){
                LeaveRecord record = new LeaveRecord( request.getLeave_id(), request.getLeave_type().getType(), request.getUser().getId(), request.getUser().getFirstName()+" "+request.getUser().getSecondName(), request.getUser().getDepartment().getName(), request.getStart_date(), 
                                                      request.getEnd_date(), request.getStartHalf(), request.getEndHalf(), request.getNumber_of_leave_days(), request.getUser().getSupervisor1(), request.getUser().getSupervisor2(), 
                                                      "No one assigned", request.getSpecial_notes(), request.getStatus(), request.getReject(), request.getFormatDateTime());
                requests.add(record);
            }else{
                LeaveRecord record = new LeaveRecord( request.getLeave_id(), request.getLeave_type().getType(), request.getUser().getId(), request.getUser().getFirstName()+" "+request.getUser().getSecondName(), request.getUser().getDepartment().getName(), request.getStart_date(), 
                                                  request.getEnd_date(), request.getStartHalf(), request.getEndHalf(), request.getNumber_of_leave_days(), request.getUser().getSupervisor1(), request.getUser().getSupervisor2(),
                                                  request.getDuty().getFirstName()+" "+request.getDuty().getSecondName(), request.getSpecial_notes(), request.getStatus(), request.getReject(), request.getFormatDateTime());
                requests.add(record);
            }                                      
        }
        return requests;
    }

    public String deleteLeave(Integer id) {
        LeaveRequest leaveRequest = leaveRequestRepository.getOne(id);
        User emp = leaveRequest.getUser();
        
        User supervisor1 = userRepository.findByFirstName(emp.getSupervisor1());
        User supervisor2 = userRepository.findByFirstName(emp.getSupervisor2());
        
        if(leaveRequest.getStatus().equals("Approved")){
            LeaveType type = leaveRequest.getLeave_type();
            Float days = leaveRequest.getNumber_of_leave_days();

            LeaveCount filter = leaveCountRepository.findByUserAndType(emp, type);
            filter.setCount(filter.getCount()-days);
            leaveCountRepository.save(filter);
            
            leaveRequestRepository.deleteById(id);   
            mailDelete(leaveRequest);
            mailSupDelete(supervisor1, leaveRequest);
            mailSupDelete(supervisor2, leaveRequest);
            return "Remove the approved request";
        }else if(leaveRequest.getStatus().equals("Rejected")){
            leaveRequestRepository.deleteById(id);
            mailDelete(leaveRequest);
            mailSupDelete(supervisor1, leaveRequest);
            mailSupDelete(supervisor2, leaveRequest);
            return "Remove the rejected request";
        }else{
            return "pending";
        }
    }

    private void mailDelete (LeaveRequest leave ) {
        User employee = leave.getUser();
		SimpleMailMessage msg = new SimpleMailMessage();
		msg.setTo(employee.getEmail());
		msg.setSubject("Remove the leave request.");
		msg.setText("Hi "+employee.getFirstName()+" "+employee.getSecondName()+",\n\n"+
					"Deleted your following "+leave.getStatus()+" leave request. \n\n"+
					"Date of request: "+leave.getFormatDateTime()+"\n"+
                    "Leave type: "+leave.getLeave_type().getType()+"\n"+
                    "Number of leave days: "+leave.getNumber_of_leave_days()+"\n"+
                    "Leave period: "+leave.getStart_date()+ " to " +leave.getEnd_date()+"\n\n"+
					"Thanks. \nBest Regards"
                    );
                     
		try {
            javaMailSender.send(msg);
			LOGGER.info(">>> E-mail send to ==> "+employee.getEmail());
		}catch (Exception e){
			LOGGER.error(">>> (MailSender) ==> "+e);
		}
    }

    private void mailSupDelete (User supervisor, LeaveRequest leave ) {
        User employee = leave.getUser();

        SimpleMailMessage mail= new SimpleMailMessage();
        mail.setTo(supervisor.getEmail());
		mail.setSubject("Remove the leave request of "+employee.getFirstName());
		mail.setText("Hi "+supervisor.getFirstName() +" "+ supervisor.getSecondName()+",\n\n"+
					"Deleted the following "+leave.getStatus()+" leave request of "+employee.getFirstName()+" "+employee.getSecondName()+". \n\n"+
					"Date of request: "+leave.getFormatDateTime()+"\n"+
                    "Leave type: "+leave.getLeave_type().getType()+"\n"+
                    "Number of leave days: "+leave.getNumber_of_leave_days()+"\n"+
                     "Leave period: "+leave.getStart_date()+ " to " +leave.getEnd_date()+"\n\n"+
					"Thanks. \nBest Regards"
                    );
        try {
            javaMailSender.send(mail);
			LOGGER.info(">>> E-mail send to ==> "+employee.getEmail());
		}catch (Exception e){
			LOGGER.error(">>> (MailSender) ==> "+e);
		}
    }

    public String approveRequest(Long check_id, LeaveRequest leaveRequest) {
        Integer id = leaveRequest.getLeave_id();
        LeaveRequest request = leaveRequestRepository.getOne(id);
        request.setStatus("Approved");

        User checked_by = userRepository.getOne(check_id);
        request.setCheckBy(checked_by);

        LocalDateTime datetime1 = LocalDateTime.now(); 
        DateTimeFormatter format = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");  
        String checkTime = datetime1.format(format);
        request.setCheckTime(checkTime);

        leaveRequestRepository.save(request);

        User emp = request.getUser();
        LeaveType type = request.getLeave_type();
        Float days = request.getNumber_of_leave_days();

        if(leaveCountRepository.existsByUserAndType(emp, type)) { 
            LeaveCount filter = leaveCountRepository.findByUserAndType(emp, type);
            filter.setCount(filter.getCount()+days);
            leaveCountRepository.save(filter);
        }else{
            LeaveCount count = new LeaveCount(emp, type, days);
            leaveCountRepository.save(count);
        }
        acceptRequest(request);

        if(request.getDuty()!=null){
            mailDutyCover(request.getDuty() , request);
        }
        
        LOGGER.info(">>> Accept Leave Request");
        return "Approved Leave Request!!!";
    }

    private void mailDutyCover (User duty, LeaveRequest leave ) {

        User employee = leave.getUser();
		SimpleMailMessage msg = new SimpleMailMessage();
		msg.setTo(duty.getEmail());
		msg.setSubject("Aditional duty to cover.");
		msg.setText("Hi "+duty.getFirstName()+" "+duty.getSecondName()+",\n"+
					"You are asigned to cover the duty of following employee in these day/s. \n\n"+
					"Name: "+employee.getFirstName()+" "+employee.getSecondName()+"\n"+
					"Role: "+employee.getRoles().stream().findFirst().get().getName()+"\n"+
                    "Department: "+employee.getDepartment().getName()+"\n"+
                    "Date/s: "+leave.getStart_date()+" to "+leave.getEnd_date()+"\n\n"+
					"Thanks. \n Best Regards"
					);

		try {
			javaMailSender.send(msg);
			LOGGER.info(">>> E-mail send to ==> "+duty.getEmail());
		}catch (Exception e){
			LOGGER.error(">>> (MailSender) ==> "+e);
		}
    }
    
    private void acceptRequest (LeaveRequest leave ) {

        User employee = leave.getUser();
		SimpleMailMessage msg = new SimpleMailMessage();
		msg.setTo(employee.getEmail());
		msg.setSubject("Accept leave request.");
		msg.setText("Hi "+employee.getFirstName()+" "+employee.getSecondName()+",\n\n"+
                    "Accept your following leave request. \n\n"+
                    "Date of request: "+leave.getFormatDateTime()+"\n"+
                    "Leave type: "+leave.getLeave_type().getType()+"\n"+
                    "Number of leave days: "+leave.getNumber_of_leave_days()+"\n"+
                    "Leave period: "+leave.getStart_date()+ " to " +leave.getEnd_date()+"\n\n"+
					"Thanks. \nBest Regards"
					);

		try {
			javaMailSender.send(msg);
			LOGGER.info(">>> E-mail send to ==> "+employee.getEmail());
		}catch (Exception e){
			LOGGER.error(">>> (MailSender) ==> "+e);
		}
    }

    private void mailReject (LeaveRequest leave ) {

        User employee = leave.getUser();
		SimpleMailMessage msg = new SimpleMailMessage();
		msg.setTo(employee.getEmail());
		msg.setSubject("Reject Leave Request.");
		msg.setText("Hi "+employee.getFirstName()+" "+employee.getSecondName()+",\n\n"+
                    "Reject your following leave request according to "+ "\""+leave.getReject()+"\""+"\n\n"+
                    "Date of request: "+leave.getFormatDateTime()+"\n"+
                    "Leave type: "+leave.getLeave_type().getType()+"\n"+
                    "Number of leave days: "+leave.getNumber_of_leave_days()+"\n"+
                    "Leave period: "+leave.getStart_date()+ " to " +leave.getEnd_date()+"\n\n"+
					"Sorry for the rejection.\nThanks\nBest Regards"
					);

		try {
			javaMailSender.send(msg);
			LOGGER.info(">>> E-mail send to ==> "+employee.getEmail());
		}catch (Exception e){
			LOGGER.error(">>> (MailSender) ==> "+e);
		}
    }
    
    public String rejectRequest(Integer id, LeaveRequest reason, Long check_id) {
        LeaveRequest request = leaveRequestRepository.getOne(id);
        request.setReject(reason.getReject());
        request.setStatus("Rejected");

        User checked_by = userRepository.getOne(check_id);
        request.setCheckBy(checked_by);

        leaveRequestRepository.save(request);

        mailReject(request);

        return "Reject the leave request!";
    }

    public List<LeaveRequest> getAbsence() {

        List<LeaveRequest> absence = new ArrayList<LeaveRequest>();
        List<LeaveRequest> requests = leaveRequestRepository.findAll();
        LocalDate today = LocalDate.now(); 

        for (LeaveRequest var : requests) {
            LocalDate start = LocalDate.parse(var.getStart_date());
            LocalDate end = LocalDate.parse(var.getEnd_date());
            List<LocalDate> totalDates = new ArrayList<>();
            while (!start.isAfter(end)) {
                totalDates.add(start);
                start = start.plusDays(1);
            }
            if(totalDates.contains(today) && var.getStatus().equals("Approved")){
                absence.add(var);
            }
        }
        return absence;
        
    }
}