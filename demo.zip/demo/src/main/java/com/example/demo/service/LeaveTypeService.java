package com.example.demo.service;

import java.util.ArrayList;
import java.util.List;
import com.example.demo.model.LeaveType;
import com.example.demo.repository.LeaveTypeRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class LeaveTypeService {

    @Autowired
    private LeaveTypeRepository leaveTypeRepository;

    public List<LeaveType> getAll() {
        return leaveTypeRepository.findAll();
    }

    public List<LeaveType> getSome() {
        List<LeaveType> leaves = new ArrayList<LeaveType>();
        
        leaves.add(leaveTypeRepository.getOne(1));
        leaves.add(leaveTypeRepository.getOne(7));
        leaves.add(leaveTypeRepository.getOne(9));
        return leaves;
    }
}    