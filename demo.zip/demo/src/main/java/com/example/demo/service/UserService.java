package com.example.demo.service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.example.demo.model.User;
import com.example.demo.payload.Employee;
import com.example.demo.payload.Supervisor;
import com.example.demo.payload.UpdateUser;
import com.example.demo.model.Department;
import com.example.demo.repository.UserRepository;
import com.example.demo.repository.DepartmentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private DepartmentRepository departmentRepository;

    @Autowired
    PasswordEncoder passwordEncoder;

    public List<Employee> getAll() {
        List<User> users = userRepository.findAll();
        List<Employee> employees = new ArrayList<Employee>();

        for (User user : users) {
            Employee employee = new Employee(user.getId(),user.getUserId(),user.getFirstName(),user.getSecondName(),user.getInitials(),user.getGender(),user.getEmail(),
            user.getResidence(),user.getContact(),user.getRoles().stream().findFirst().get().getName().toString(),user.getDepartment().getName(), user.getDesignation(),
            user.getSupervisor1(),user.getSupervisor2(),user.getJoinDate(),user.getConfirmDate(),user.getStatus(),user.getAnnual(),
            user.getCasual(),user.getMedical());
            employees.add(employee);
        }
        return employees;
    }

    public String resignEmployee(Employee emp) {
        User employee = userRepository.getOne(emp.getId());
        employee.setStatus("Resign");
        employee.setResignDate(emp.getResignDate());
        userRepository.save(employee);
        return "Employee resign succesfully!";
    }

    static void sql(Long emp_id, Long role_id){
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/leave_management?useSSL=false&serverTimezone=UTC&useLegacyDatetimeCode=false", "root", "")) {
    
            String sql = "UPDATE user_roles SET role_id=? WHERE user_id=?";

            PreparedStatement statement = conn.prepareStatement(sql);
            statement.setString(1, role_id.toString());
            statement.setString(2, emp_id.toString());
            
            int rowsUpdated = statement.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("An existing user was updated successfully!");
            } 
            
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    public String updateEmployee(Long id, UpdateUser employee) {

        User employeeToUpdate = userRepository.getOne(id);
        employeeToUpdate.setUserId(employee.getUserId());
        employeeToUpdate.setUsername(employee.getEmail());
        employeeToUpdate.setFirstName(employee.getFirstName());
        employeeToUpdate.setSecondName(employee.getSecondName());
        employeeToUpdate.setInitials(employee.getInitials());
        employeeToUpdate.setGender(employee.getGender());
        employeeToUpdate.setEmail(employee.getEmail());
        employeeToUpdate.setResidence(employee.getResidence());
        employeeToUpdate.setContact(employee.getContact());

        String role_name = employee.getRole();

        if(role_name.equals("Supervisor")){
            sql(id, 1L);      
        }else if(role_name.equals("Permanent")){
            sql(id, 2L);  
        }else if(role_name.equals("Probation")){
            sql(id, 3L);  
        }else if(role_name.equals("Intern")){
            sql(id, 4L);  
        }else if(role_name.equals("Contract")){
            sql(id, 5L);  
        }else if(role_name.equals("Admin")){
            sql(id, 6L);  
        } 

        Department department = departmentRepository.findByName(employee.getDepartment());
        employeeToUpdate.setDepartment(department);
        employeeToUpdate.setDesignation(employee.getDesignation());
        employeeToUpdate.setSupervisor1(employee.getSupervisor1());
        employeeToUpdate.setSupervisor2(employee.getSupervisor2());
        employeeToUpdate.setJoinDate(employee.getJoinDate());
        employeeToUpdate.setConfirmDate(employee.getConfirmDate());
        employeeToUpdate.setAnnual(employee.getAnnual());
        employeeToUpdate.setCasual(employee.getCasual());
        employeeToUpdate.setMedical(employee.getMedical());

        userRepository.save(employeeToUpdate);

        return "User updated successfully!";
    }

    public Employee searchById(Long id) {

        User user = userRepository.getOne(id);
        Employee employee = new Employee(user.getId(),user.getUserId(),user.getFirstName(),user.getSecondName(),user.getInitials(),user.getGender(),user.getEmail(),
            user.getResidence(),user.getContact(),user.getRoles().stream().findFirst().get().getName().toString(),user.getDepartment().getName(),user.getDesignation(),
            user.getSupervisor1(),user.getSupervisor2(),user.getJoinDate(),user.getConfirmDate(),user.getStatus(),user.getAnnual(),
            user.getCasual(),user.getMedical());

        return employee;
    }

    public List<Supervisor> searchSupervisors() {

        List<User> users = userRepository.findAll();
        List<Supervisor> supervisors = new ArrayList<Supervisor>();

        for (User user : users) {
            if(user.getRoles().stream().findFirst().get().getName().toString().equals("Supervisor")){
                Supervisor supervisor = new Supervisor(user.getId(),user.getFirstName(),user.getSecondName(),user.getEmail(),
                user.getDepartment().getName());
                supervisors.add(supervisor);
            }
        }
        return supervisors;
    }

}