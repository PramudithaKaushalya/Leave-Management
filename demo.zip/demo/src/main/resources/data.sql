INSERT IGNORE INTO roles(name) VALUES('Supervisor');
INSERT IGNORE INTO roles(name) VALUES('Permanent');
INSERT IGNORE INTO roles(name) VALUES('Probation');
INSERT IGNORE INTO roles(name) VALUES('Intern');
INSERT IGNORE INTO roles(name) VALUES('Contract');
INSERT IGNORE INTO roles(name) VALUES('Admin');

-- INSERT IGNORE INTO department(department_name) VALUES('Human Resources');
-- INSERT IGNORE INTO department(department_name) VALUES('Finance');
-- INSERT IGNORE INTO department(department_name) VALUES('Senior Management');
-- INSERT IGNORE INTO department(department_name) VALUES('Data Science');
-- INSERT IGNORE INTO department(department_name) VALUES('Enterprise Support');
-- INSERT IGNORE INTO department(department_name) VALUES('Quality Assurance');
-- INSERT IGNORE INTO department(department_name) VALUES('Software Development');
-- INSERT IGNORE INTO department(department_name) VALUES('Business Development');
-- INSERT IGNORE INTO department(department_name) VALUES('Research & Development');

-- INSERT IGNORE INTO leave_type(type) VALUES('Casual');
-- INSERT IGNORE INTO leave_type(type) VALUES('Medical');
-- INSERT IGNORE INTO leave_type(type) VALUES('Maternity');
-- INSERT IGNORE INTO leave_type(type) VALUES('Paternit');
-- INSERT IGNORE INTO leave_type(type) VALUES('Annual');
-- INSERT IGNORE INTO leave_type(type) VALUES('Lieu');
-- INSERT IGNORE INTO leave_type(type) VALUES('Special');
-- INSERT IGNORE INTO leave_type(type) VALUES('Cover Up');
-- INSERT IGNORE INTO leave_type(type) VALUES('No Pay');
